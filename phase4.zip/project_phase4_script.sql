-- DATABASE FOR 3SQUARE FOOD BANK
-- All inputted data is fake as the website does not publicly display this info
-- But this would be functional with real data!!

CREATE TABLE donor (
  donor_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  first_name VARCHAR(45) NOT NULL,
  last_name VARCHAR(45) NOT NULL,
  PRIMARY KEY  (donor_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE donation (
  donation_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  donor_id INT UNSIGNED NOT NULL,
  donation_date DATE NOT NULL,
  PRIMARY KEY  (donation_id),
  KEY idx_fk_donor_id (donor_id),
  CONSTRAINT `fk_donor_donation` FOREIGN KEY (donor_id) REFERENCES donor (donor_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE storage_facility (
  storage_location VARCHAR(45) NOT NULL,
  space_available_ft INT UNSIGNED NOT NULL,
  PRIMARY KEY  (storage_location)
) ENGINE=InnoDB; 


CREATE TABLE food_donation (
  donation_id INT UNSIGNED NOT NULL,
  food_type VARCHAR(45) NOT NULL,
  food_lbs INT UNSIGNED NOT NULL,
  storage_location VARCHAR(45) NOT NULL,
  KEY idx_fk_donation_id (donation_id),
  CONSTRAINT `fk_food_dono` FOREIGN KEY (donation_id) REFERENCES donation (donation_id) ON DELETE RESTRICT ON UPDATE CASCADE,
  KEY idx_fk_storage_location(storage_location),
  CONSTRAINT `fk_food_location` FOREIGN KEY (storage_location) REFERENCES storage_facility (storage_location) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB; 

CREATE TABLE money_donation (
	donation_id INT UNSIGNED NOT NULL,
    money_amount INT UNSIGNED,
    KEY idx_fk_donation_money(donation_id),
    CONSTRAINT `fk_donation_money` FOREIGN KEY (donation_id) REFERENCES donation (donation_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB; 

CREATE TABLE volunteer (
	volunteer_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    first_name VARCHAR(45) NOT NULL,
    last_name VARCHAR(45) NOT NULL,
    storage_location VARCHAR(45) NOT NULL,
    PRIMARY KEY  (volunteer_id),
    KEY idx_fk_volunteer_location(storage_location),
    CONSTRAINT `fk_volunteer_location` FOREIGN KEY (storage_location) REFERENCES storage_facility (storage_location) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB; 


CREATE TABLE volunteer_info (
	volunteer_id INT UNSIGNED NOT NULL,
    job_type VARCHAR(45) NOT NULL,
    total_hours INT UNSIGNED,
    KEY idx_fk_volunteer_hours(volunteer_id),
    CONSTRAINT `fk_volunteer_hours` FOREIGN KEY (volunteer_id) REFERENCES volunteer (volunteer_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB; 
    
    
    
INSERT INTO donor VALUES (1,'Gabriel','Weber'),
(2,'John','Johnson'),
(3, 'Matt', 'Peterson'),  
(4, 'Isaac', 'Nickels'),  
(5, 'Carlos', 'Brown'),  
(6, 'Gavin', 'Bailey'),  
(7, 'Dylan', 'Adams'),  
(8, 'Ryan', 'Brooks'),  
(9, 'Paige', 'Green'),  
(10, 'George', 'Hall'),  
(11, 'Samantha', 'Jones'),  
(12, 'Trevor', 'Kelly'),  
(13, 'Xavier', 'Miller'), 
(14, 'Tyler', 'Morgan'),
(15, 'Jonas', 'Reid');

INSERT INTO donation VALUES (1, 1, DATE('2022-03-31')),
(2, 2, DATE('2022-04-01')),
(3, 3, DATE('2022-04-02')),
(4, 4, DATE('2022-04-03')),
(5, 3, DATE('2022-04-03')),
(6, 5, DATE('2022-04-04')),
(7, 6, DATE('2022-04-04')),
(8, 7, DATE('2022-04-05')),
(9, 8, DATE('2022-04-05')),
(10, 9, DATE('2022-04-05')),
(11, 10, DATE('2022-04-05')),
(12, 2, DATE('2022-04-06')),
(13, 5, DATE('2022-04-08')),
(14, 11, DATE('2022-04-08')),
(15, 12, DATE('2022-04-08')),
(16, 9, DATE('2022-04-09')),
(17, 13, DATE('2022-04-09')),
(18, 14, DATE('2022-04-10')),
(19, 15, DATE('2022-04-10')),
(20, 6, DATE('2022-04-10'));

INSERT INTO money_donation VALUES (1, 50),
 (2, 10),
 (3, 5),
 (4, 1000),
 (5, 1823),
 (6, 180),
 (7, 54),
 (8, 300),
 (9, 100),
 (10, 25),
 (11, 100),
 (12, 52),
 (13, 2000),
 (14, 820),
 (15, 140),
 (16, 50),
 (17, 320),
 (18, 200),
 (19, 25),
 (20, 25);

INSERT INTO storage_facility VALUES ('Stephanie', 300), ('Saint Rose', 400);

INSERT INTO food_donation VALUES (1, 'Canned goods', 10, 'Stephanie'),
(2, 'Canned goods', 3, 'Saint Rose'),
(3, 'Perishables', 5, 'Saint Rose'),
(4, 'Canned goods', 8, 'Saint Rose'),
(5, 'Perishables', 12, 'Stephanie'),
(6, 'Canned goods', 1, 'Saint Rose'),
(7, 'Canned goods', 2, 'Saint Rose'),
(8, 'Canned goods', 3, 'Saint Rose'),
(9, 'Perishables', 8, 'Saint Rose'),
(10, 'Canned goods', 4, 'Stephanie'),
(11, 'Canned goods', 2, 'Stephanie'),
(12, 'Perishables', 9, 'Stephanie'),
(13, 'Perishables', 10, 'Saint Rose'),
(14, 'Canned goods', 20, 'Saint Rose'),
(15, 'Canned goods', 30, 'Saint Rose'),
(16, 'Canned goods', 6, 'Saint Rose'),
(17, 'Perishables', 19, 'Stephanie'),
(18, 'Perishables', 11, 'Saint Rose'),
(19, 'Canned goods', 13, 'Saint Rose'),
(20, 'Canned goods', 12, 'Saint Rose');

INSERT INTO volunteer VALUES (1, 'Gabriel', 'Weber', 'Saint Rose'),
(2, 'Benjamin', 'Rose', 'Stephanie'),
(3, 'Jorge', 'Russell', 'Saint Rose'),
(4, 'Josh', 'Stewart', 'Stephanie'),
(5, 'Timmy', 'Turner', 'Stephanie'),
(6, 'Damian', 'Ward', 'Stephanie'),
(7, 'Ely', 'West', 'Saint Rose'),
(8, 'Leeroy', 'Jenkins', 'Stephanie'),
(9, 'Calvin', 'Harris', 'Stephanie'),
(10, 'Jack', 'Foster', 'Saint Rose');

INSERT INTO volunteer_info VALUES (1, 'Financial Review', 352),
(2, 'Sorting/Organizing', 153),
(3, 'Sorting/Organizing', 1421),
(4, 'Sorting/Organizing', 100),
(5, 'Distributing Food', 509),
(6, 'Financial Review', 1055),
(7, 'Sorting/Organizing', 400),
(8, 'Sorting/Organizing', 153),
(9, 'Distributing Food', 304),
(10, 'Distributing Food', 152);

